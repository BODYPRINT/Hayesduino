# Required Hardware

# Arduino UNO
# Ethernet Shield

# Recommended Hardware

# Arduino Mega 2560
# Ethernet Shield

## Connecting to your computer

The Arduino AVR series boards use TTL-level RS232 communications (Arduino ARM series use 3.3V).  Some computers, such as the Commodore 8-bit line of computers, use TTL-Level serial, but most use RS232-level serial communications.  If your target platform uses RS232-level serial you will need to construct a proper RS232 circuit.  I recommend using a MAX237 chip as it allows all 7 used lines to be level-shifted with a single chip.