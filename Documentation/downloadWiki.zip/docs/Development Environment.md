# Development Environment for Hayesduino

You will need the following software components to successfully utilize this source code:

# Visual Studio 2010
# Visual Micro ([http://www.visualmicro.com/](http://www.visualmicro.com/)) - you do not need to purchase unless you want to debug the sketch in Visual Studio
# Arduino 1.5.x ([http://arduino.cc/en/Main/Software](http://arduino.cc/en/Main/Software))

You can probably get away with just having the Arduino 1.5.x studio using the avr compiler, but I cannot support you in your endeavors.