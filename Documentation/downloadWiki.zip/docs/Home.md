# Project Description

I have moved the code to GitHub ([https://github.com/plbyrd/hayesduino](https://github.com/plbyrd/hayesduino)).  This project will remain for documentation purposes.

## [E-Mail Group](https://groups.google.com/forum/?fromgroups#!forum/hayesduino)
I have opened a group on Google for Hayesduino.  Be sure to subscribe to get the latest news and updates about Hayesduino and to ask any support questions you may have.

## [Development Environment](Development-Environment)

## [Required Hardware](Required-Hardware)

## [Documentation](Documentation)