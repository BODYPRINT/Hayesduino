# Hayesduino Documentation

{anchor:contents}
## Contents
# [What Is It?](#whatisit)
# [History](#history)
# [Implemented Hayes Command Set](#hayes)
## [Standard Commands](#standardhayes)
## [Extended Commands](#extendedhayes)
## [Setting Defaults](#settingdefaults)
## [Factory Reset](#factoryreset)
## [Non-Standard Commands](#nonstandardhayes)
## [Queries](#queries)
# [Hardware](#hardware)
## [Pin Usage](#pinusage)
# [License](#license)
# Platform-Specific Docs
## [Commodore Userport](Commodore-Userport)
## [Apple II](Apple-II)
## [Atari 8-Bit](Atari-8-Bit)
## [RS232](RS232)

{anchor:whatisit}
## What Is It?

Hayesduino is an Arduino sketch that provides a bridge between the world of the Internet and small devices that do not have built-in ethernet capabilities.  Old computers, such as the Commodore 64, Apple II and Atari 800 have serial ports, but do not have readily available Internet solutions with wide software support.  While specialized solutions do exist for these platforms, they all require specialized software to use them and do not lend themselves to more general usage such as simply opening a socket, sending some data, and/or receiving some data.

Hayesduino bridges this gap by emulating a Hayes compatible modem.  This allows users to initiate Internet communications via sockets that are opened by "dialing" to a hostname and port.  An example would be initiating a telnet session with a host by simply typing _atdt hostname:23_ and waiting for the host to respond.  Using this technique, any online socket can be reached and communicated with.

Hayesduino could have accomplished this without emulating a modem, but there needed to be a good way to allow the small machine to receive incoming connections.  The three platforms listed above were all very popular systems for hosting BBS (bulletin board systems) which would accept calls over a telephone line via modem.  Hayesduino simulates the incoming phone call whenever the software receives an inbound connection on port 23 (this is changeable in the code).  When an incoming connection is detected, the Hayesduino will toggle the DCE-DCD line to trigger the remote software to answer the incoming "call".  In this way a classic BBS can be hooked up directly to the Internet.

[Contents](#contents) | [Home](Home)
{anchor:history}
## History

Hayesduino started in early 2013 as the firmware for the Comet BBS product which is to be sold as a commercial product.  The owner of the Comet BBS project and Payton Byrd agreed that the firmware would be made open-source as the Comet BBS product is based on the Arduino Uno and thus easily reproducible as a hobby project.  Although the Comet BBS hardware project appears to be stalled, the development of the firmware is not stalled and I, Payton Byrd, have decided to move forward with open-sourcing the firmware as the Hayesduino project.



[Contents](#contents) | [Home](Home)
{anchor:hayes}
## Implemented Hayes Command Set

[Contents](#contents) | [Home](Home)
{anchor:standardhayes}
### Standard Commands

**All commands are prefixed with the letters "AT".  Commands can be chained (but not queries).**

|| Command | Description | Uno | Mega 2560 ||
| / | Replay last command | Yes | Yes |
| A | Answer Call | Yes | Yes |
| D | Dial {"*"} | Yes | Yes |
| DT | Dial {"**"} | Yes | Yes |
| DP | Dial {"**"} | Yes | Yes |
| E0 | Echo Off {"***"} | Yes | Yes |
| E1 | Echo On | Yes | Yes |
| H | Hang Up Call | Yes | Yes |
| H0 | Hang Up Call | Yes | Yes |
| M0 | Unused | No | No |
| O | Return to Data Mode | Yes | Yes |
| Q0 | Quiet Mode Off {"***"} | Yes | Yes |
| Q1 | Quiet Mode On {"***"} | Yes | Yes |
| V0 | Verbose Mode Off - Returns numeric result codes {"***"} | Yes | Yes |
| V1 | Verbose Mode On - Returns textual result codes {"***"} | Yes | Yes |
| X0 | Unused | No | No |
| X1 | Unused | No | No |
| X2 | Unused | No | No |
| &W | Write settings as default to EEPROM | Yes | Yes |
| Z | Reset to default settings | Yes | Yes |

_{"*"} Use without a space to dial a phonebook entry.  ex: ATD1 would dial phonebook entry 1_
_{"**"} Use with a space to dial a hostname or IP address.  ex: ATDT BBS.PAYTONBYRD.COM would dial the hostname on port 23_
_{"***"} Saves when AT&W is called_

[Contents](#contents) | [Home](Home)
{anchor:extendedhayes}
### Extended Commands

Hayesduino knows of the following S-Register extended commands:

_* All S-Registers are preserved when performing AT&W._
|| Command | Description | Uno | Mega 2560 | Notes ||
| S0 | Auto answer, 0 mean answer immediately, > 0 means to answer after the number of rings in S1. | Yes | Yes | |
| S1 | Rings before auto answer | No | No | Value is saved, but currently the feature is not implemented. |
| S2 | Escape Character | Yes | Yes | Defaults to '+' |
| S3 | Carriage Return Character | No | No | Value is saved, but currently the feature is not implemented. |
| S4 | Line Feed Character | No | No | Value is saved, but currently the feature is not implemented. |
| S5 | Backspace Character | Yes | Yes | |
| S6 | Wait Blind Dial | No | No | Not Applicable |
| S7 | Wait for Carrier | No | No | Not Applicable |
| S8 | Pause for Comma | No | No | Not Applicable |
| S9 | CD Response Time | No | No | Value is saved, but currently the feature is not implemented. |
| S10 | Delay Hangup | No | No | Value is saved, but currently the feature is not implemented. |
| S11 | DTMF | No | No | Value is saved, but currently the feature is not implemented. |
| S12 | ESC Guard Time | No | No | Value is saved, but currently the feature is not implemented. |
| S18 | Test Timer | No | No | Value is saved, but currently the feature is not implemented. |
| S25 | Delay DTR | No | No | Value is saved, but currently the feature is not implemented. |
| S26 | Delay RTS to CTS | No | No | Value is saved, but currently the feature is not implemented. |
| S30 | Inactivity Timer | No | No | Value is saved, but currently the feature is not implemented. |
| S37 | Line Speed | Yes | Yes | See [Baud Table](#baudtable) Below.  Saves to EEPROM immediately. |
| S38 | Delay Forced | No | No | Value is saved, but currently the feature is not implemented. |

{anchor:baudtable}
### Baud Table
|| Code | Speed ||
| 0, 1, 2, 3 | 300 Baud |
| 5 | 1200 Baud |
| 6, any not listed here | 2400 Baud |
| 8 | 9600 Baud |
| 10 | 14400 Baud |
| 11 | 28800 Baud |
| 12 | 57600 Baud |
| 13 | 115,200 Baud |
[Contents](#contents) | [Home](Home)
{anchor:factoryreset}
### Factory Reset

To perform a "Factory Reset", you must issue _AT&F_ to the modem.  The first time you do this it will prompt you to enter _AT&F_ again to confirm your intent to reset the modem to default.  Entering any other command will abort the reset.

[Contents](#contents) | [Home](Home)
{anchor:nonstandardhayes}
### Non-Standard Commands

|| Command | Description | Uno | Mega 2560 | Notes ||
| T | Get DATETIME | Yes | Yes | Supply server name. Ex: ATT TIME.NIST.GOV |
| S90 | DCD Inverted | Yes | Yes | 0 = Normal, 1 = Invert. 2 = ALWAYS ON,  Saves to EEPROM immediately. |
| S100 | Set Phonebook 0 | Yes | Yes | Sets a hostname or IP address to the phonebook. |
| S101 | Set Phonebook 1 | Yes | Yes | Sets a hostname or IP address to the phonebook. |
| S102 | Set Phonebook 2 | Yes | Yes | Sets a hostname or IP address to the phonebook. |
| S103 | Set Phonebook 3 | Yes | Yes | Sets a hostname or IP address to the phonebook. |
| S104 | Set Phonebook 4 | Yes | Yes | Sets a hostname or IP address to the phonebook. |
| S105 | Set Phonebook 5 | Yes | Yes | Sets a hostname or IP address to the phonebook. |
| S106 | Set Phonebook 6 | Yes | Yes | Sets a hostname or IP address to the phonebook. |
| S107 | Set Phonebook 7 | Yes | Yes | Sets a hostname or IP address to the phonebook. |
| S108 | Set Phonebook 8 | Yes | Yes | Sets a hostname or IP address to the phonebook. |
| S109 | Set Phonebook 9 | Yes | Yes | Sets a hostname or IP address to the phonebook. |
| S200 | Set Baud Rate | Yes | Yes | Accepts baud rate as whole number, does not save to EEPROM |
| S300 - S305 | Bytes of MAC address | Yes | Yes | Saves immediately. |
| S306 - S309 | Bytes of IP Address | Yes | Yes | Saves immediately. |
| S310 - S313 | Bytes of Gateway Address | Yes | Yes | Saves immediately. |
| S314 - S317 | Bytes of DNS Address | Yes | Yes | Saves immediately. |
| S318 | Use DHCP | Yes | Yes | 0 = No, 1 = Yes, Saves immediately. |

[Contents](#contents) | [Home](Home)
{anchor:queries}
### Queries

[Contents](#contents) | [Home](Home)
{anchor:hardware}
## Hardware

[Contents](#contents) | [Home](Home)
{anchor:pinusage}
### Pin Usage

|| Function | Uno | Mega ||
| DCE_CTS | 2 | 22 |
| DCE_DCD | 7 | 23 |
| DCE_RI | 4 | 24 |
| DCE_DTR | 5 | 25 |
| DCE_RTS | 6 | 27 |
| DSR | 3 | 29 |
| DCE_Tx | 0 | 19 |
| DCE_Rx | 1 | 18 |
| GROUND | GND | GND |
| Carrier Detect | 8 | 8 |

[Contents](#contents) | [Home](Home)
{anchor:license}
## License

Hayesduino is released under the LGPL.  Why?  Because EthernetClient and EthernetServer both had to be modified because they essentially suck, and these files are under the LGPL.  I started to write my own drivers but ran out of time (and will) to do it right, so I decided to go this route.

[Contents](#contents) | [Home](Home)
