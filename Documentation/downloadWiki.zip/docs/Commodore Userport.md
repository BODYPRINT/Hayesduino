# Commodore Userport

The Commodore userport is not a true RS232 device, but RS232 communication is implemented in software in the Kernal of the computer.  The userport provides all of the lines necessary for RS232 communications, but it is all TTL-level.

Here is a breakdown of the userport pins used to emulate RS232 communications.

![](Commodore Userport_http://www.hardwarebook.info/images/9/96/Dzm12dreh.png)

|| Commodore Func. || Direction || Modem Func. || Pin || Name || Description || Uno || Mega 2560 ||
| GND | | GND | A | GND | Protective Ground | GND | GND |
| RxD | <-- | TxD | B {"+"} C | FLAG2 + PB0 | Receive Data (Must be applied to both pins) | 0 | 19 |
| RTS | --> | CTS | D | PB1 | Ready to Send | 2 | 22 |
| DTR | --> | DCD | E | PB2 | Data Terminal Ready | 7 | 23 |
| RI | <-- | RI | F | PB3 | Ring Indicator | 4 | 24 |
| DCD | <-- | DTR | H | PB4 | Data Carrier Detect | 5 | 25 |
| CTS | <-- | RTS | K | PB6 | Clear to Send | 6 | 26 |
| DSR | Unused | DSR | L | PB7 | Data Set Ready | 3 | 27 |
| TxD | --> | RxD | M | PA2 | Transmit Data | 1 | 18 |
| GRND | | GRND | N | GRND | Signal Ground | GND | GND |

#### _credit: [http://www.gamesx.com/hwb/co_C64Rs232UserPort.html](http___www.gamesx.com_hwb_co_C64Rs232UserPort.html)_